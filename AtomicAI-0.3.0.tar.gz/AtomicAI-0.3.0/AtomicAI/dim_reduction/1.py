a = []
print(len(a))
